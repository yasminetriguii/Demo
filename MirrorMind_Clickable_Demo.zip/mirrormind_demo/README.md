# MirrorMind Demo

A self-contained clickable frontend demo for the MirrorMind hackathon concept.

## Run locally

Open `index.html` directly in a browser, or run a local server:

```bash
python -m http.server 8000
```

Then open http://localhost:8000

## Deploy

This is a static site and can be deployed to Vercel, Netlify, GitHub Pages, or any static hosting provider. Upload the contents of this folder.

The buttons are interactive: Focus Sentinel opens an intervention modal, Replay shows a cognitive replay, and Simulate Recovery updates the mental-state metrics.
