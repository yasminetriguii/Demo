"""Provider adapter boundary for Presage.

Presage credentials and SDK/API details are intentionally not fabricated here.
Map your authorized Presage SDK/webhook output into this normalized shape:

{
  "heartRate": 72,
  "breathingRate": 14,
  "engagement": 68,
  "facialSignals": {...}
}

Then feed those values into the state-fusion layer in server.py.
"""

from typing import Any


def normalize_presage(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "heartRate": payload.get("heartRate"),
        "breathingRate": payload.get("breathingRate"),
        "engagement": payload.get("engagement"),
        "facialSignals": payload.get("facialSignals", {}),
    }
