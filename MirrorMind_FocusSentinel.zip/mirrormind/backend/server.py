import asyncio
import json
import os
import random
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
DB = Path(__file__).resolve().parent / "mirrormind.db"

app = FastAPI(title="MirrorMind API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=ROOT / "frontend"), name="static")


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            ts REAL NOT NULL,
            focus REAL NOT NULL,
            stress REAL NOT NULL,
            confidence REAL NOT NULL,
            energy REAL NOT NULL,
            engagement REAL NOT NULL,
            source TEXT NOT NULL,
            context TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS interventions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            ts REAL NOT NULL,
            trigger TEXT NOT NULL,
            message TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


init_db()


def clamp(x: float) -> float:
    return max(0.0, min(100.0, x))


def local_state(prev: dict[str, float], activity: dict[str, Any]) -> dict[str, float]:
    """Demo signal fusion. Replace/add a Presage adapter for physiological signals."""
    stress = prev["stress"]
    focus = prev["focus"]
    engagement = prev["engagement"]
    confidence = prev["confidence"]
    energy = prev["energy"]

    keys = activity.get("keys", 0)
    mouse = activity.get("mouse", 0)
    idle = activity.get("idleSeconds", 0)
    rapid = activity.get("rapidErrors", 0)
    cursor_idle = float(activity.get("cursorIdleSeconds", idle) or 0)

    stress += random.uniform(-2.0, 2.0) + min(rapid * 1.2, 5)
    focus += random.uniform(-2.0, 2.0) - (2.0 if idle > 12 else 0)
    engagement += random.uniform(-1.5, 1.5) + (1.0 if mouse or keys else -1.0)
    confidence += random.uniform(-1.0, 1.0) - (1.5 if rapid else 0)
    energy += random.uniform(-1.0, 1.0) - (0.5 if idle > 20 else 0)

    if keys > 20 and rapid == 0:
        stress -= 0.5
        focus += 0.5
    if idle > 30:
        engagement -= 3
        focus -= 2
    if cursor_idle > 25 and keys < 3 and mouse < 2:
        engagement -= 4
        focus -= 3
        stress += 1.5

    return {k: round(clamp(v), 1) for k, v in {
        "focus": focus,
        "stress": stress,
        "confidence": confidence,
        "energy": energy,
        "engagement": engagement,
    }.items()}


def state_label(s: dict[str, float]) -> str:
    if s["stress"] >= 75 and s["focus"] <= 45:
        return "critical"
    if s["stress"] >= 58 or s["focus"] <= 45 or s["engagement"] <= 45:
        return "overloaded"
    if s["focus"] >= 72 and s["stress"] <= 45 and s["engagement"] >= 65:
        return "focused"
    return "productive"


async def gemini_intervention(state: dict[str, float], context: str) -> str:
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return fallback_intervention(state)

    model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    prompt = f"""You are MirrorMind, a concise human-performance copilot.
Current signals: {json.dumps(state)}
Context: {context or 'user is working on a task'}
Give exactly ONE supportive intervention under 20 words. Do not diagnose. Do not mention that you are an AI. Prefer a concrete next action."""
    payload = {"contents": [{"parts": [{"text": prompt}]}]}
    try:
        async with httpx.AsyncClient(timeout=12) as client:
            r = await client.post(url, params={"key": key}, json=payload)
            r.raise_for_status()
            data = r.json()
            return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception:
        return fallback_intervention(state)


def fallback_intervention(state: dict[str, float]) -> str:
    if state["stress"] >= 70:
        return "Your stress is climbing. Take a 20-second reset, then come back to the next small step."
    if state["focus"] <= 45:
        return "Your focus is slipping. Want to pause and break the task into one smaller step?"
    if state["engagement"] <= 45:
        return "You seem less engaged than a few minutes ago. Try changing the task or taking a short reset."
    return "You’re doing well. Keep the next step small and focused."


async def elevenlabs_audio(text: str) -> str | None:
    key = os.getenv("ELEVENLABS_API_KEY")
    voice = os.getenv("ELEVENLABS_VOICE_ID")
    if not key or not voice:
        return None
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice}"
    headers = {"xi-api-key": key, "Content-Type": "application/json", "Accept": "audio/mpeg"}
    payload = {"text": text, "model_id": "eleven_multilingual_v2"}
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            import base64
            return base64.b64encode(r.content).decode("ascii")
    except Exception:
        return None


@app.get("/")
async def root():
    return FileResponse(ROOT / "frontend" / "index.html")


@app.get("/api/health")
async def health():
    return {
        "ok": True,
        "gemini": bool(os.getenv("GEMINI_API_KEY")),
        "elevenlabs": bool(os.getenv("ELEVENLABS_API_KEY") and os.getenv("ELEVENLABS_VOICE_ID")),
    }


@app.get("/api/session/{session_id}/replay")
async def replay(session_id: str):
    conn = db()
    rows = conn.execute("SELECT * FROM signals WHERE session_id=? ORDER BY ts", (session_id,)).fetchall()
    interventions = conn.execute("SELECT * FROM interventions WHERE session_id=? ORDER BY ts", (session_id,)).fetchall()
    conn.close()
    if not rows:
        return {"summary": "No session data yet.", "signals": [], "interventions": []}
    avg = {k: round(sum(r[k] for r in rows) / len(rows), 1) for k in ["focus", "stress", "confidence", "energy", "engagement"]}
    peak_stress = max(rows, key=lambda r: r["stress"])
    peak_focus = max(rows, key=lambda r: r["focus"])
    summary = (
        f"Your session had an average focus of {avg['focus']}% and engagement of {avg['engagement']}%. "
        f"Stress peaked at {peak_stress['stress']}%, while your highest focus reached {peak_focus['focus']}%. "
        f"MirrorMind delivered {len(interventions)} intervention(s)."
    )
    return {"summary": summary, "averages": avg, "signals": [dict(r) for r in rows[-120:]], "interventions": [dict(r) for r in interventions]}


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(ws: WebSocket, session_id: str):
    await ws.accept()
    state = {"focus": 70.0, "stress": 30.0, "confidence": 72.0, "energy": 78.0, "engagement": 75.0}
    last_intervention = 0.0
    try:
        while True:
            try:
                raw = await asyncio.wait_for(ws.receive_text(), timeout=1.0)
                activity = json.loads(raw)
            except asyncio.TimeoutError:
                activity = {}
            except WebSocketDisconnect:
                raise
            except Exception:
                activity = {}

            state = local_state(state, activity)
            label = state_label(state)
            now = time.time()
            context = activity.get("context", "")
            conn = db()
            conn.execute(
                "INSERT INTO signals(session_id,ts,focus,stress,confidence,energy,engagement,source,context) VALUES(?,?,?,?,?,?,?,?,?)",
                (session_id, now, state["focus"], state["stress"], state["confidence"], state["energy"], state["engagement"], "browser_demo", context),
            )
            conn.commit()
            conn.close()

            intervention = None
            audio = None
            cursor = {"idle_seconds": float(activity.get("cursorIdleSeconds", 0) or 0), "should_nudge": False}
            cursor_idle = cursor["idle_seconds"]
            # Cooldown prevents the assistant from becoming annoying. Cursor nudges require
            # a sustained pause plus very little keyboard/mouse activity, so normal reading
            # and typing do not trigger interruptions.
            cursor_trigger = cursor_idle >= 25 and activity.get("keys", 0) < 3 and activity.get("mouse", 0) < 2
            state_trigger = state["stress"] >= 65 or state["focus"] <= 40 or state["engagement"] <= 40
            if now - last_intervention > 18 and (state_trigger or cursor_trigger):
                intervention = await gemini_intervention(state, context)
                cursor["should_nudge"] = cursor_trigger
                audio = await elevenlabs_audio(intervention)
                conn = db()
                conn.execute("INSERT INTO interventions(session_id,ts,trigger,message) VALUES(?,?,?,?)", (session_id, now, label, intervention))
                conn.commit()
                conn.close()
                last_intervention = now

            await ws.send_json({
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "state": state,
                "label": label,
                "intervention": intervention,
                "audio": audio,
                "cursor": cursor,
            })
    except WebSocketDisconnect:
        return
