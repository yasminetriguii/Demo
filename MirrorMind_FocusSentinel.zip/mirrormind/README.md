# MirrorMind

A runnable hackathon MVP for a real-time human-performance copilot.

## What works out of the box
- Browser webcam permission and live camera preview
- Live Mental State Orb
- Focus, stress, confidence, energy and engagement signals
- Typing/mouse/activity signals from the browser
- Real-time WebSocket updates
- Gemini-powered intervention reasoning when `GEMINI_API_KEY` is configured
- ElevenLabs spoken intervention when `ELEVENLABS_API_KEY` is configured
- Local fallback reasoning/voice-free mode when keys are absent
- Session timeline and Cognitive Replay summary
- SQLite persistence

## Run

Requirements: Python 3.10+

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python server.py
```

Open http://localhost:8000

Optional `.env`:

```env
GEMINI_API_KEY=your_key
GEMINI_MODEL=gemini-2.5-flash
ELEVENLABS_API_KEY=your_key
ELEVENLABS_VOICE_ID=your_voice_id
```

The app intentionally keeps the sensing layer provider-neutral. If you have Presage credentials/SDK access, implement the adapter described in `backend/presage_adapter.py` rather than hard-coding undocumented endpoints.
