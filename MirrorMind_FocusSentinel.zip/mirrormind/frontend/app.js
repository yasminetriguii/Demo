const sessionId = crypto.randomUUID();
let ws;
let lastIntervention = '';
let points = [];
let keyCount = 0;
let mouseCount = 0;
let lastActivity = Date.now();
let lastCursorMove = Date.now();
let rapidErrors = 0;
let mediaStream = null;
let sentinelToast = null;
let lastSentinelNudge = 0;

const $ = id => document.getElementById(id);

async function startCamera(){
  try{
    mediaStream = await navigator.mediaDevices.getUserMedia({video:true,audio:false});
    $('video').srcObject = mediaStream;
    $('cameraBtn').textContent='Camera active';
    $('cameraBtn').disabled=true;
  }catch(e){ $('cameraBtn').textContent='Camera unavailable'; }
}
$('cameraBtn').onclick=startCamera;

function connect(){
  const proto=location.protocol==='https:'?'wss':'ws';
  ws=new WebSocket(`${proto}://${location.host}/ws/${sessionId}`);
  ws.onopen=()=>{ $('statusDot').style.background='#72e59b'; $('statusText').textContent='Live'; };
  ws.onclose=()=>{ $('statusDot').style.background='#ff8a8a'; $('statusText').textContent='Reconnecting...'; setTimeout(connect,1500); };
  ws.onmessage=e=>render(JSON.parse(e.data));
}

function send(){
  if(!ws || ws.readyState!==1)return;
  const now=Date.now();
  ws.send(JSON.stringify({
    keys:keyCount,
    mouse:mouseCount,
    idleSeconds:(now-lastActivity)/1000,
    cursorIdleSeconds:(now-lastCursorMove)/1000,
    cursorX:window.__mmCursorX ?? null,
    cursorY:window.__mmCursorY ?? null,
    rapidErrors,
    context:$('context').value
  }));
  keyCount=0;mouseCount=0;rapidErrors=0;
}

document.addEventListener('keydown',e=>{keyCount++;lastActivity=Date.now(); if(e.key==='Backspace')rapidErrors++;});
document.addEventListener('mousemove',e=>{
  mouseCount++;
  lastActivity=Date.now();
  lastCursorMove=Date.now();
  window.__mmCursorX=e.clientX;
  window.__mmCursorY=e.clientY;
});
setInterval(send,1000);
setInterval(()=>{
  $('clock').textContent=new Date().toLocaleTimeString();
  const idle=Math.floor((Date.now()-lastCursorMove)/1000);
  $('idleTimer').textContent=`${idle}s`;
  if(idle < 10){
    $('sentinelStatus').textContent='Active interaction detected';
    $('sentinelDetail').textContent='Your cursor is moving normally. MirrorMind is watching for meaningful changes in your work rhythm.';
    $('sentinelDot').style.background='#72e59b';
    $('sentinelDot').style.boxShadow='0 0 14px #72e59b';
  } else if(idle < 25){
    $('sentinelStatus').textContent='Cursor has paused';
    $('sentinelDetail').textContent='You may be reading or thinking. MirrorMind will wait before interrupting.';
    $('sentinelDot').style.background='#f1c36b';
    $('sentinelDot').style.boxShadow='0 0 14px #f1c36b';
  } else {
    $('sentinelStatus').textContent='Possible focus drop detected';
    $('sentinelDetail').textContent='Your cursor has been still for a while. If you are stuck, MirrorMind can give you a small next step.';
    $('sentinelDot').style.background='#ff9b72';
    $('sentinelDot').style.boxShadow='0 0 14px #ff9b72';
  }
},1000);

function showFocusToast(message){
  if(sentinelToast) return;
  const el=document.createElement('div');
  el.className='focus-toast';
  el.innerHTML=`<strong>MirrorMind noticed a pause</strong><p>${escapeHtml(message)}</p><div class="focus-toast-actions"><button type="button" id="resetBtn">20-second reset</button><button type="button" id="dismissBtn">Dismiss</button></div>`;
  document.body.appendChild(el);
  sentinelToast=el;
  $('resetBtn').onclick=()=>{
    lastCursorMove=Date.now();
    lastActivity=Date.now();
    el.remove(); sentinelToast=null;
    $('intervention').textContent='Take 20 seconds away from the task. When you return, choose one small next step.';
  };
  $('dismissBtn').onclick=()=>{ el.remove(); sentinelToast=null; };
}

function escapeHtml(value){
  return String(value).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}

function render(data){
  const s=data.state;
  for(const k of ['focus','stress','confidence','energy','engagement']){
    $(k).textContent=`${Math.round(s[k])}%`;
    $(`${k}Bar`).style.width=`${s[k]}%`;
  }
  $('label').textContent=data.label.toUpperCase();
  $('orb').className=`orb ${data.label}`;
  points.push({t:Date.now(),focus:s.focus,stress:s.stress,engagement:s.engagement});
  if(points.length>90)points.shift();
  draw();
  if(data.intervention){
    lastIntervention=data.intervention;
    $('intervention').textContent=data.intervention;
    if(data.audio){ playAudio(data.audio); }
  }
  if(data.cursor && data.cursor.should_nudge && Date.now()-lastSentinelNudge>20000){
    lastSentinelNudge=Date.now();
    showFocusToast(data.intervention || 'Your cursor has been still for a while. Check whether you are stuck or simply thinking.');
  }
}

function playAudio(base64){
  try{new Audio(`data:audio/mpeg;base64,${base64}`).play();}catch(e){}
}
$('speakBtn').onclick=()=>{ if(lastIntervention && 'speechSynthesis' in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(lastIntervention));} };

function draw(){
  const c=$('chart'),ctx=c.getContext('2d'),w=c.width,h=c.height;
  ctx.clearRect(0,0,w,h);
  ctx.strokeStyle='#ffffff10';ctx.lineWidth=1;
  for(let y=0;y<=4;y++){const yy=20+y*(h-40)/4;ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();}
  const lines=[['focus','#819eff'],['stress','#ff9b72'],['engagement','#8dd9b1']];
  for(const [key,color] of lines){
    ctx.strokeStyle=color;ctx.lineWidth=2;ctx.beginPath();
    points.forEach((p,i)=>{const x=i*(w-20)/Math.max(points.length-1,1)+10;const y=h-20-(p[key]/100)*(h-40);i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();
  }
}

$('replayBtn').onclick=async()=>{
  const r=await fetch(`/api/session/${sessionId}/replay`);const d=await r.json();$('replay').textContent=d.summary;
};

connect();
