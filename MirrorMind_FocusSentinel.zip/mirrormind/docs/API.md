# MirrorMind API

- `GET /api/health` checks whether Gemini and ElevenLabs credentials are configured.
- `GET /api/session/{session_id}/replay` returns session averages, signal history, and interventions.
- `WS /ws/{session_id}` accepts browser activity JSON and streams fused state JSON back every second.

Example activity payload:

```json
{
  "keys": 8,
  "mouse": 14,
  "idleSeconds": 0.8,
  "rapidErrors": 0,
  "context": "calculus assignment"
}
```
